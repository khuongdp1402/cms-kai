document.getElementById('btnConnect').addEventListener('click', async () => {
  const statusEl = document.getElementById('status');
  statusEl.style.color = '#38bdf8';
  statusEl.innerText = '⏳ Đang tự động trích xuất Cookie...';

  try {
    const allCookies = await chrome.cookies.getAll({});
    const zaloCookies = allCookies.filter(c => c.domain.includes('zalo.me'));
    
    if (!zaloCookies || zaloCookies.length === 0) {
      statusEl.style.color = '#ef4444';
      statusEl.innerText = '⚠️ Vui lòng mở và đăng nhập oa.zalo.me hoặc chat.zalo.me trước!';
      return;
    }

    const cookieStr = zaloCookies.map(c => `${c.name}=${c.value}`).join('; ');
    const imei = 'zalo_ext_' + Math.random().toString(36).substring(2, 10);

    const res = await fetch('https://twine-eliminate-shredding.ngrok-free.dev/webhooks/zalo/connect_bridge', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        cookies: cookieStr,
        imei: imei,
        userAgent: navigator.userAgent
      })
    });

    const data = await res.json();
    if (data.status === 'success') {
      statusEl.style.color = '#10b981';
      statusEl.innerText = '🎉 ĐÃ KẾT NỐI ZALO VỀ CHATWOOT THÀNH CÔNG!';
    } else {
      statusEl.style.color = '#ef4444';
      statusEl.innerText = '❌ Lỗi: ' + data.message;
    }
  } catch (e) {
    statusEl.style.color = '#ef4444';
    statusEl.innerText = '❌ Lỗi kết nối: ' + e.message;
  }
});
